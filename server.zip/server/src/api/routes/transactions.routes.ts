import { Router } from 'express';
import { authMiddleware } from '../../middleware/auth.middleware';
import { asyncHandler } from '../../middleware/error.middleware';
import { getTransactionsHandler, updateTransactionHandler } from '../../controllers/transactions.controller';

const router = Router();

router.get('/', authMiddleware, asyncHandler(getTransactionsHandler));
router.patch('/:transactionId', authMiddleware, asyncHandler(updateTransactionHandler));

export default router;